﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhileLoop
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int start,end;
            int sum = 0;
            
            Console.Write("Start: ");
            start = Convert.ToInt32(Console.ReadLine());

            Console.Write("End: ");
            end = Convert.ToInt32(Console.ReadLine());


            int currentnum = start;

            Console.Write("\nEven numbers: ");

            while (currentnum <= end)
            {
                
                if (currentnum % 2 == 0)
                {
                    Console.Write(currentnum + " ");
                    sum += currentnum;
                }

                currentnum++;
            }
            
            Console.WriteLine("\nSum: " + sum);
        }
        
    }
}
