﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoWhile
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int start, end;
            int sum = 0;

            Console.Write("Start: ");
            start = Convert.ToInt32(Console.ReadLine());

            Console.Write("End: ");
            end = Convert.ToInt32(Console.ReadLine());
            int currentnum = start;

            Console.Write("\nEven numbers: ");
            do
            {
                if (currentnum % 2 == 0)
                {
                    Console.Write(currentnum + " ");
                    sum += currentnum;
                }
                currentnum++;
            }

            while (currentnum <= end);

            Console.WriteLine("\nSum: " + sum);

        }
    }
}
